from django.shortcuts import render,HttpResponse,redirect
from app01 import models
from app01.utils.pagination import Pagination
# Create your views here.
# ########################部门管理########################
def depart_list(request):
    """部门列表"""
    #去数据库获取部门列表
    queryset = models.Department.objects.all()
    page_object = Pagination(request,queryset,page_size=3)
    context = {
        'queryset': page_object.page_queryset,  # 分完页的数据
        "page_string": page_object.html ()     # 分页的页码
    }
    return render(request,'depart_list.html',context)

def depart_add(request):
    """添加部门"""
    if request.method == "GET":
        return render(request, 'depart_add.html')
    #获取用户POST提交过来的数据
    title = request.POST.get("title")
    # 保存到数据库
    models.Department.objects.create(title=title)
    # 重定向回部门列表
    return redirect("/depart/list/")
def depart_delete(request):
    """删除部门"""
    #获取ID,http://127.0.0.1:8000/depart/delete/?nid=1
    nid = request.GET.get('nid')
    #删除
    models.Department.objects.filter(id=nid).delete()
    # 跳回部门列表
    return redirect("/depart/list/")

def depart_edit(request,nid):
    """编辑部门"""
    if request.method == "GET":
        row_object = models.Department.objects.filter(id=nid).first()
        #print(row_object.id,row_object.title)
        return render(request, 'depart_edit.html',{'row_object':row_object})
    title = request.POST.get("title")
    #根据ID找到数据库中的数据，并进行更新
    models.Department.objects.filter(id=nid).update(title=title)
    # 重定向回部门列表
    return redirect("/depart/list/")


# ########################用户管理########################
def user_list(request):
    """用户列表"""
    #去数据库获取用户列表
    queryset = models.UserInfo.objects.all()
    page_object = Pagination(request,queryset,page_size=2)
    context = {
        'queryset': page_object.page_queryset,  # 分完页的数据
        "page_string": page_object.html ()  # 分页的页码
    }
    for obj in queryset:
        print(obj.id,obj.name,obj.password,obj.age,obj.account,obj.creat_time.strftime("%y-%m-%d"),obj.gender,obj.get_gender_display(),obj.depart_id,obj.depart.title)
    return render(request,'user_list.html',context)

def user_add(request):
    """添加用户"""
    if request.method == "GET":
        context = {
            'gender_choices': models.UserInfo.gender_choices,
            'depart_list': models.Department.objects.all ()
        }
        return render(request, 'user_add.html', context)
    #获取用户POST提交过来的数据
    user = request.POST.get("user")
    pwd = request.POST.get ("pwd")
    age = request.POST.get ("age")
    account = request.POST.get ("account")
    ctime = request.POST.get ("creat_time")
    gender_id = request.POST.get ("gender")
    depart_id = request.POST.get ("department")

    # 保存到数据库
    models.UserInfo.objects.create(name=user,password=pwd,age=age,account=account,creat_time=ctime,gender=gender_id,depart_id=depart_id)
    # 重定向回用户列表
    return redirect("/user/list/")
# ##########ModelForm##########
from django import forms
class UserModelForm(forms.ModelForm):
    class Meta:
        model = models.UserInfo
        fields = ["name","password","age","account","creat_time","gender","depart"]
    #定义一个新方法，把每一输入框都加上样式class="form-control"
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        #循环找到所有的插件，添加样式
        for name,field in self.fields.items():
            #可以通过判断，不加该样式
            #if name == "password":
                #continue
            field.widget.attrs = {"class":"form-control","placeholder":field.label}

def user_model_form_add(request):
    if request.method == "GET":
        form = UserModelForm()
        return render (request, 'user_model_form_add.html',{"form":form})
    # 获取用户POST提交过来的数据，并效验
    form = UserModelForm(data=request.POST)
    if form.is_valid():
        #models.UserInfo.objects.create()
        form.save()
        return redirect("/user/list/")
    #校验失败（在页面显示错误信息）
    return render (request, 'user_model_form_add.html',{"form":form})
def user_edit(request,nid):
    """编辑用户"""
    row_object = models.UserInfo.objects.filter ( id=nid ).first ()
    if request.method == "GET":
        # 根据ID去数据库获取要编辑那一行数据
        form = UserModelForm ( instance=row_object )
        return render ( request, 'user_edit.html', {"form": form} )
    form = UserModelForm ( data=request.POST,instance=row_object)
    if form.is_valid():
        form.save()
        return redirect("/user/list/")
    #校验失败（在页面显示错误信息）
    return render (request, 'user_edit.html',{"form":form})

def user_delete(request,nid):
    """删除用户"""
    models.UserInfo.objects.filter (id=nid).delete()
    # 跳回部门列表
    return redirect ( "/user/list/" )

# ########################靓号管理########################
from django.core.validators import RegexValidator,ValidationError
from django import forms
from django.utils.safestring import mark_safe
class PrettyNumForm(forms.ModelForm):
    #手机号不重复，验证方式一正则表达式。
    mobile = forms.CharField(
        label="手机号",
        validators=[RegexValidator(r'^1\d{10}$','手机号格式错误')],
    )
    class Meta:
        model = models.PrettyNum
        # 自己定义需要使用的数据库中字段
        #fields = ["mobile","price","level","status"]
        #取数据库中所有字段
        fields = "__all__"
    #定义一个新方法，把每一输入框都加上样式class="form-control"
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        #循环找到所有的插件，添加样式
        for name,field in self.fields.items():
            #可以通过判断，不加该样式
            #if name == "password":
                #continue
            field.widget.attrs = {"class":"form-control","placeholder":field.label}
        #手机号不重复，验证方式二，写一个方法。
    def clean_mobile(self):
            #当前编辑的那一行的ID
            #print(self.instance.pk)
        text_mobile = self.cleaned_data["mobile"]
            #排除自己以外，其它手机号是否存在重复
        #exists = models.PrettyNum.objects.exclude(id=self.instance.pk).filter(mobile=text_mobile).exists()
            # 其它手机号是否存在重复
        exists = models.PrettyNum.objects.filter ( mobile=text_mobile ).exists ()
        if exists:
            raise ValidationError("手机号已存在")
        return text_mobile

def prettynum_list(request):
    """靓号列表"""
    #去数据库获取靓号列表，按等级降序显示
    #queryset = models.PrettyNum.objects.all().order_by("-level")
    #靓号分页功能
    #创建多条（页）记录
    # for i in range(300):
    #     models.PrettyNum.objects.create(mobile="18188888818",price=10,level=1,status=1)


    #去数据库获取靓号列表，按用户提供的搜索内容显示
    data_dict = {}
    search_data = request.GET.get('q',"")
    if search_data:
        data_dict["mobile__contains"]=search_data
    #使用分页组建
    queryset = models.PrettyNum.objects.filter(**data_dict).order_by("-level")
    page_object = Pagination(request,queryset)
    context = {
        'search_data': search_data,
        'queryset': page_object.page_queryset,     #分完页的数据
        "page_string": page_object.html()     #分页的页码
    }

    for obj in queryset:
        #print(obj.id,obj.mobile,obj.price,obj.get_level_display(),obj.get_status_display())
        return render(request,'prettynum_list.html',context)

def prettynum_add(request):
    if request.method == "GET":
        form = PrettyNumForm()
        return render (request, 'prettynum_add.html',{"form":form})
    # 获取用户POST提交过来的数据，并效验
    form = PrettyNumForm(data=request.POST)
    if form.is_valid():
        #models.UserInfo.objects.create()
        form.save()
        return redirect("/prettynum/list/")
    #校验失败（在页面显示错误信息）
    return render (request, 'prettynum_add.html',{"form":form})

class PrettyNumEditForm(forms.ModelForm):
    mobile = forms.CharField(disabled=True,label="手机号")
    class Meta:
        model = models.PrettyNum
        # 自己定义需要使用的数据库中字段,显示但是不修改mobile字段。
        fields = ["mobile","price","level","status"]
    #定义一个新方法，把每一输入框都加上样式class="form-control"
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        #循环找到所有的插件，添加样式
        for name,field in self.fields.items():
            field.widget.attrs = {"class":"form-control","placeholder":field.label}

def prettynum_edit(request,nid):
    """编辑靓号"""
    row_object = models.PrettyNum.objects.filter ( id=nid ).first ()
    if request.method == "GET":
        # 根据ID去数据库获取要编辑那一行数据
        form = PrettyNumEditForm ( instance=row_object )
        return render ( request, 'prettynum_edit.html', {"form": form} )
    form = PrettyNumEditForm ( data=request.POST,instance=row_object)
    if form.is_valid():
        form.save()
        return redirect("/prettynum/list/")
    #校验失败（在页面显示错误信息）
    return render (request, 'prettynum_edit',{"form":form})

def prettynum_delete(request,nid):
    """删除靓号"""
    models.PrettyNum.objects.filter (id=nid).delete()
    # 跳回靓号列表
    return redirect ( "/prettynum/list/" )

def admin_list(request):
    """管理员列表"""
    #去数据库获取管理员列表，按用户提供的搜索内容显示
    data_dict = {}
    search_data = request.GET.get('q',"")
    if search_data:
        data_dict["username__contains"]=search_data
    #使用分页组建
    queryset = models.AdminInfo.objects.filter(**data_dict)
    page_object = Pagination(request,queryset)
    context = {
        'search_data': search_data,
        'queryset': page_object.page_queryset,     #分完页的数据
        "page_string": page_object.html()     #分页的页码
    }

    for obj in queryset:
        return render(request,'admin_list.html',context)